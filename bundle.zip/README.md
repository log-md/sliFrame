<img src='demo.png'>

# Add Iframe to Google Slides 

A Chrome extension that allows you to add Iframes to Google Slides. 

# Installation 

Google store does not allow us to publish this extension (we inject HTML into Google Slides using JS). The only way to install this is through developer mode. 

1. Download 


## License

MIT
