# sudo apt install imagemagick
convert logo_864x864.png -resize 16x16 icon-16.png 
convert logo_864x864.png -resize 32x32 icon-32.png 
convert logo_864x864.png -resize 48x48 icon-48.png
convert logo_864x864.png -resize 128x128 icon-128.png
